package GUI;

import javax.swing.SwingUtilities;
import model.GestorePiattaforma;

public class UninaMultiCloudApp {
    public static void main(String[] args) {
        // MODIFICA CON I TUOI DATI DI CONNESSIONE
        String url = "jdbc:mysql://localhost:3306/UninaMultiCloud";
        String user = "root";
        String password = "tua_password";
        
        GestorePiattaforma gestore = new GestorePiattaforma(url, user, password);
        SwingUtilities.invokeLater(() -> new LoginFrame(gestore));
    }
}