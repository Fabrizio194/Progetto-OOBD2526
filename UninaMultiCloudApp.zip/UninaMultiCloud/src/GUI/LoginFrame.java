package GUI;

import java.awt.*;
import javax.swing.*;
import model.GestorePiattaforma;
import model.Utente;

public class LoginFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private JTextField txtMatricola;
    private JPasswordField txtPassword;
    private JButton btnAccedi, btnCancella;
    private GestorePiattaforma gestore;

    public LoginFrame(GestorePiattaforma gestore) {
        this.gestore = gestore;
        setTitle("UninaMultiCloud - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel title = new JLabel("LOGIN PAGE", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        add(new JLabel("Matricola:"), gbc);
        txtMatricola = new JTextField(15);
        gbc.gridx = 1;
        add(txtMatricola, gbc);

        gbc.gridy = 2;
        gbc.gridx = 0;
        add(new JLabel("Password:"), gbc);
        txtPassword = new JPasswordField(15);
        gbc.gridx = 1;
        add(txtPassword, gbc);

        JPanel pnlBottoni = new JPanel(new FlowLayout());
        btnAccedi = new JButton("ACCEDI");
        btnCancella = new JButton("CANCELLA");
        pnlBottoni.add(btnAccedi);
        pnlBottoni.add(btnCancella);
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        add(pnlBottoni, gbc);

        btnAccedi.addActionListener(e -> accedi());
        btnCancella.addActionListener(e -> cancella());

        setVisible(true);
    }

    private void accedi() {
        String matricola = txtMatricola.getText().trim();
        String password = new String(txtPassword.getPassword());
        Utente utente = gestore.verificaLogin(matricola, password);
        if (utente != null) {
            JOptionPane.showMessageDialog(this, "Login effettuato! Benvenuto " + utente.getNomeUtente());
            dispose();
            new HomeFrame(utente, gestore);
        } else {
            JOptionPane.showMessageDialog(this, "Matricola o password errati.", "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cancella() {
        txtMatricola.setText("");
        txtPassword.setText("");
        txtMatricola.requestFocus();
    }
}