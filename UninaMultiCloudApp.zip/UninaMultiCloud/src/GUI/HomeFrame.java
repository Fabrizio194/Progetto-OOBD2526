package GUI;

import java.awt.*;
import javax.swing.*;
import model.GestorePiattaforma;
import model.Utente;

public class HomeFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;

    public HomeFrame(Utente utente, GestorePiattaforma gestore) {
        this.utente = utente;
        this.gestore = gestore;
        setTitle("UninaMultiCloud - Home");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel title = new JLabel("HOME FRAME", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        JPanel pnlBottoni = new JPanel(new GridLayout(4, 1, 10, 10));
        pnlBottoni.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JButton btnPlaylist = new JButton("ACCESSO PLAYLIST");
        JButton btnRiproduzione = new JButton("RIPRODUZIONE CONTENUTI");
        JButton btnModifiche = new JButton("GESTIONE MODIFICHE");
        JButton btnUpload = new JButton("+ UPLOAD CONTENUTO");

        pnlBottoni.add(btnPlaylist);
        pnlBottoni.add(btnRiproduzione);
        pnlBottoni.add(btnModifiche);
        pnlBottoni.add(btnUpload);
        add(pnlBottoni, BorderLayout.CENTER);

        JLabel info = new JLabel("Utente: " + utente.getNomeUtente() + " (" + utente.getMatricola() + ")", SwingConstants.CENTER);
        add(info, BorderLayout.SOUTH);

        btnPlaylist.addActionListener(e -> new PlaylistFrame(utente, gestore));
        btnRiproduzione.addActionListener(e -> new StartPlaylistFrame(utente, gestore, null));
        btnModifiche.addActionListener(e -> new ModificheFrame(utente, gestore));
        btnUpload.addActionListener(e -> new UploadContentFrame(utente, gestore));

        setVisible(true);
    }
}