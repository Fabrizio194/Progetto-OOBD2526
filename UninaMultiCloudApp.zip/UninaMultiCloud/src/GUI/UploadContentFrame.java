package GUI;

import java.awt.*;
import javax.swing.*;
import model.GestorePiattaforma;
import model.Utente;
import model.Audio;
import model.Video;

public class UploadContentFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;
    private JComboBox<String> cmbTipo;
    private JPanel pnlExtra;
    private JTextField txtTitolo, txtDescrizione;
    private JTextField txtFormato, txtFreq, txtTesto;
    private JTextField txtRisoluzione, txtUrl, txtFrameRate;

    public UploadContentFrame(Utente utente, GestorePiattaforma gestore) {
        this.utente = utente;
        this.gestore = gestore;
        setTitle("Carica Contenuto");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel pnlCentro = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; pnlCentro.add(new JLabel("Classe:"), gbc);
        cmbTipo = new JComboBox<>(new String[]{"Audio", "Video"});
        gbc.gridx = 1; pnlCentro.add(cmbTipo, gbc);

        y++;
        gbc.gridx = 0; gbc.gridy = y; pnlCentro.add(new JLabel("Titolo:"), gbc);
        txtTitolo = new JTextField(20);
        gbc.gridx = 1; pnlCentro.add(txtTitolo, gbc);

        y++;
        gbc.gridx = 0; gbc.gridy = y; pnlCentro.add(new JLabel("Descrizione:"), gbc);
        txtDescrizione = new JTextField(20);
        gbc.gridx = 1; pnlCentro.add(txtDescrizione, gbc);

        pnlExtra = new JPanel(new GridBagLayout());
        pnlExtra.setVisible(false);
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.gridwidth = 2;
        pnlCentro.add(pnlExtra, gbc);

        add(pnlCentro, BorderLayout.CENTER);

        JPanel pnlBottoni = new JPanel(new FlowLayout());
        JButton btnCarica = new JButton("CARICA");
        JButton btnAnnulla = new JButton("ANNULLA");
        pnlBottoni.add(btnCarica);
        pnlBottoni.add(btnAnnulla);
        add(pnlBottoni, BorderLayout.SOUTH);

        cmbTipo.addActionListener(e -> aggiornaCampiExtra());
        aggiornaCampiExtra();

        btnCarica.addActionListener(e -> carica());
        btnAnnulla.addActionListener(e -> dispose());

        setVisible(true);
    }

    private void aggiornaCampiExtra() {
        pnlExtra.removeAll();
        String tipo = (String) cmbTipo.getSelectedItem();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 3, 3, 3);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        int row = 0;

        if (tipo.equals("Audio")) {
            pnlExtra.add(new JLabel("Formato:"), gbc);
            txtFormato = new JTextField(10);
            gbc.gridx = 1; pnlExtra.add(txtFormato, gbc);
            row++;
            gbc.gridx = 0; gbc.gridy = row;
            pnlExtra.add(new JLabel("Frequenza (Hz):"), gbc);
            txtFreq = new JTextField(10);
            gbc.gridx = 1; pnlExtra.add(txtFreq, gbc);
            row++;
            gbc.gridx = 0; gbc.gridy = row;
            pnlExtra.add(new JLabel("Testo Brano:"), gbc);
            txtTesto = new JTextField(15);
            gbc.gridx = 1; pnlExtra.add(txtTesto, gbc);
        } else {
            pnlExtra.add(new JLabel("Risoluzione:"), gbc);
            txtRisoluzione = new JTextField(10);
            gbc.gridx = 1; pnlExtra.add(txtRisoluzione, gbc);
            row++;
            gbc.gridx = 0; gbc.gridy = row;
            pnlExtra.add(new JLabel("URL Sorgente:"), gbc);
            txtUrl = new JTextField(15);
            gbc.gridx = 1; pnlExtra.add(txtUrl, gbc);
            row++;
            gbc.gridx = 0; gbc.gridy = row;
            pnlExtra.add(new JLabel("Frame Rate:"), gbc);
            txtFrameRate = new JTextField(10);
            gbc.gridx = 1; pnlExtra.add(txtFrameRate, gbc);
        }
        pnlExtra.setVisible(true);
        pnlExtra.revalidate();
        pnlExtra.repaint();
        pack();
    }

    private void carica() {
        String titolo = txtTitolo.getText().trim();
        String descrizione = txtDescrizione.getText().trim();
        if (titolo.isEmpty() || descrizione.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Titolo e descrizione obbligatori.");
            return;
        }
        String tipo = (String) cmbTipo.getSelectedItem();
        try {
            if (tipo.equals("Audio")) {
                String formato = txtFormato.getText().trim();
                double freq = Double.parseDouble(txtFreq.getText().trim());
                String testo = txtTesto.getText().trim();
                Audio audio = gestore.caricaAudio(utente.getMatricola(), titolo, descrizione, 180, formato, freq, testo);
                if (audio != null) {
                    JOptionPane.showMessageDialog(this, "Audio caricato con ID " + audio.getId());
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Errore nel caricamento.", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                String risoluzione = txtRisoluzione.getText().trim();
                String url = txtUrl.getText().trim();
                int frameRate = Integer.parseInt(txtFrameRate.getText().trim());
                Video video = gestore.caricaVideo(utente.getMatricola(), titolo, descrizione, 300, risoluzione, url, frameRate);
                if (video != null) {
                    JOptionPane.showMessageDialog(this, "Video caricato con ID " + video.getId());
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Errore nel caricamento.", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Inserisci valori numerici corretti.", "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }
}