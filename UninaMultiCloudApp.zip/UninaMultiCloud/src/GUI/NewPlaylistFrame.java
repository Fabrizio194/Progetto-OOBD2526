package GUI;

import java.awt.*;
import javax.swing.*;
import model.GestorePiattaforma;
import model.Playlist;
import model.Utente;

public class NewPlaylistFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;
    private PlaylistFrame parent;
    private JTextField txtNome;
    private JComboBox<String> cmbTipo;
    private JPanel pnlExtra;
    private JTextField txtTag, txtPin, txtNote;
    private JSpinner spinMaxMembri;

    public NewPlaylistFrame(Utente utente, GestorePiattaforma gestore, PlaylistFrame parent) {
        this.utente = utente;
        this.gestore = gestore;
        this.parent = parent;
        setTitle("Nuova Playlist");
        setSize(450, 350);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel pnlCentro = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; pnlCentro.add(new JLabel("Nome:"), gbc);
        txtNome = new JTextField(20);
        gbc.gridx = 1; pnlCentro.add(txtNome, gbc);

        y++;
        gbc.gridx = 0; gbc.gridy = y; pnlCentro.add(new JLabel("Tipo:"), gbc);
        cmbTipo = new JComboBox<>(new String[]{"Pubblica", "Privata", "Condivisa"});
        gbc.gridx = 1; pnlCentro.add(cmbTipo, gbc);

        pnlExtra = new JPanel(new GridBagLayout());
        pnlExtra.setVisible(false);
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.gridwidth = 2;
        pnlCentro.add(pnlExtra, gbc);

        add(pnlCentro, BorderLayout.CENTER);

        JPanel pnlBottoni = new JPanel(new FlowLayout());
        JButton btnCrea = new JButton("CREA PLAYLIST");
        JButton btnAnnulla = new JButton("ANNULLA");
        pnlBottoni.add(btnCrea);
        pnlBottoni.add(btnAnnulla);
        add(pnlBottoni, BorderLayout.SOUTH);

        cmbTipo.addActionListener(e -> aggiornaCampiExtra());
        aggiornaCampiExtra();

        btnCrea.addActionListener(e -> creaPlaylist());
        btnAnnulla.addActionListener(e -> dispose());

        setVisible(true);
    }

    private void aggiornaCampiExtra() {
        pnlExtra.removeAll();
        String tipo = (String) cmbTipo.getSelectedItem();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 3, 3, 3);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        int row = 0;

        if (tipo.equals("Pubblica")) {
            pnlExtra.add(new JLabel("Tag Ricerca:"), gbc);
            txtTag = new JTextField(15);
            gbc.gridx = 1; pnlExtra.add(txtTag, gbc);
        } else if (tipo.equals("Privata")) {
            pnlExtra.add(new JLabel("PIN Accesso:"), gbc);
            txtPin = new JTextField(15);
            gbc.gridx = 1; pnlExtra.add(txtPin, gbc);
            row++;
            gbc.gridx = 0; gbc.gridy = row;
            pnlExtra.add(new JLabel("Note:"), gbc);
            txtNote = new JTextField(15);
            gbc.gridx = 1; pnlExtra.add(txtNote, gbc);
        } else if (tipo.equals("Condivisa")) {
            pnlExtra.add(new JLabel("Max Membri:"), gbc);
            spinMaxMembri = new JSpinner(new SpinnerNumberModel(5, 1, 100, 1));
            gbc.gridx = 1; pnlExtra.add(spinMaxMembri, gbc);
        }
        pnlExtra.setVisible(true);
        pnlExtra.revalidate();
        pnlExtra.repaint();
        pack();
    }

    private void creaPlaylist() {
        String nome = txtNome.getText().trim();
        if (nome.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Inserisci un nome.");
            return;
        }
        String tipo = (String) cmbTipo.getSelectedItem();
        Playlist playlist = null;
        if (tipo.equals("Pubblica")) {
            String tag = txtTag.getText().trim();
            playlist = gestore.creaPlaylistPubblica(utente.getMatricola(), nome, tag);
        } else if (tipo.equals("Privata")) {
            String pin = txtPin.getText().trim();
            String note = txtNote.getText().trim();
            playlist = gestore.creaPlaylistPrivata(utente.getMatricola(), nome, pin, note);
        } else if (tipo.equals("Condivisa")) {
            playlist = gestore.creaPlaylistCondivisa(utente.getMatricola(), nome);
        }
        if (playlist != null) {
            JOptionPane.showMessageDialog(this, "Playlist creata con ID " + playlist.getId());
            parent.caricaPlaylist("Tutte le Playlist");
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Errore nella creazione.");
        }
    }
}