package GUI;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.GestorePiattaforma;
import model.Playlist;
import model.PlaylistPubblica;
import model.PlaylistPrivata;
import model.PlaylistCondivisa;
import model.Utente;

public class PlaylistFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;
    private JComboBox<String> cmbFiltro;
    private JTable tabellaPlaylist;
    private DefaultTableModel model;

    public PlaylistFrame(Utente utente, GestorePiattaforma gestore) {
        this.utente = utente;
        this.gestore = gestore;
        setTitle("Playlist - " + utente.getNomeUtente());
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel pnlFiltro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlFiltro.add(new JLabel("Filtra:"));
        cmbFiltro = new JComboBox<>(new String[]{"Tutte le Playlist", "Pubbliche", "Private", "Condivise"});
        pnlFiltro.add(cmbFiltro);
        JButton btnFiltra = new JButton("Applica");
        pnlFiltro.add(btnFiltra);
        add(pnlFiltro, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"Nome", "Tipo", "Metadati"}, 0);
        tabellaPlaylist = new JTable(model);
        JScrollPane scroll = new JScrollPane(tabellaPlaylist);
        add(scroll, BorderLayout.CENTER);

        JPanel pnlBottoni = new JPanel(new FlowLayout());
        JButton btnNuova = new JButton("+ NEW PLAYLIST");
        JButton btnRiproduci = new JButton("RIPRODUCI");
        pnlBottoni.add(btnNuova);
        pnlBottoni.add(btnRiproduci);
        add(pnlBottoni, BorderLayout.SOUTH);

        caricaPlaylist("Tutte le Playlist");

        btnFiltra.addActionListener(e -> caricaPlaylist((String) cmbFiltro.getSelectedItem()));
        btnNuova.addActionListener(e -> new NewPlaylistFrame(utente, gestore, this));
        btnRiproduci.addActionListener(e -> avviaRiproduzione());

        setVisible(true);
    }

    public void caricaPlaylist(String filtro) {
        model.setRowCount(0);
        List<Playlist> lista = gestore.getPlaylistsByOwner(utente.getMatricola());
        for (Playlist p : lista) {
            String tipo;
            String metadati = "";
            if (p instanceof PlaylistPubblica) {
                tipo = "Pubblica";
                PlaylistPubblica pp = (PlaylistPubblica) p;
                metadati = "Vis: " + pp.getNumVisualizzazioni() + ", Tag: " + pp.getTagRicerca();
            } else if (p instanceof PlaylistPrivata) {
                tipo = "Privata";
                PlaylistPrivata pr = (PlaylistPrivata) p;
                metadati = "Note: " + (pr.getNote() != null && !pr.getNote().isEmpty() ? pr.getNote() : "nessuna");
            } else if (p instanceof PlaylistCondivisa) {
                tipo = "Condivisa";
                metadati = "Condivisa con altri";
            } else {
                tipo = "Sconosciuto";
            }
            if (!filtro.equals("Tutte le Playlist") && !tipo.equals(filtro.substring(0, filtro.length()-1))) continue;
            model.addRow(new Object[]{p.getNome(), tipo, metadati});
        }
    }

    private void avviaRiproduzione() {
        int row = tabellaPlaylist.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleziona una playlist.");
            return;
        }
        String nome = (String) model.getValueAt(row, 0);
        List<Playlist> lista = gestore.getPlaylistsByOwner(utente.getMatricola());
        Playlist scelta = null;
        for (Playlist p : lista) {
            if (p.getNome().equals(nome)) {
                scelta = p;
                break;
            }
        }
        if (scelta != null) {
            new StartPlaylistFrame(utente, gestore, scelta);
        }
    }
}