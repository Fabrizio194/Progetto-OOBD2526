package GUI;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.GestorePiattaforma;
import model.Modifica;
import model.Utente;

public class ModificheFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;
    private JTable tabella;
    private DefaultTableModel model;

    public ModificheFrame(Utente utente, GestorePiattaforma gestore) {
        this.utente = utente;
        this.gestore = gestore;
        setTitle("Gestione Modifiche - " + utente.getNomeUtente());
        setSize(600, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{"Playlist", "Tipo Operazione", "Stato", "Data/Ora"}, 0);
        tabella = new JTable(model);
        add(new JScrollPane(tabella), BorderLayout.CENTER);

        caricaModifiche();

        setVisible(true);
    }

    private void caricaModifiche() {
        List<Modifica> modifiche = gestore.getModificheForUser(utente.getMatricola());
        for (Modifica m : modifiche) {
            String nomePlaylist = "Playlist " + m.getIdPlaylistCondivisa();
            model.addRow(new Object[]{
                nomePlaylist,
                m.getTipoOperazione(),
                m.getStato(),
                m.getDataOra().toString()
            });
        }
    }
}