package model;

import java.time.LocalDate;

public class Audio extends ElementoMultimediale {
    private String formato;
    private double frequenza;
    private String testoBrano;

    // Costruttore senza dataCreazione
    public Audio(int id, String titolo, String descrizione, int durata, 
                 String matricolaProprietario, String formato, double frequenza, String testoBrano) {
        this(id, titolo, descrizione, durata, matricolaProprietario, formato, frequenza, testoBrano, LocalDate.now());
    }

    // Costruttore completo con dataCreazione
    public Audio(int id, String titolo, String descrizione, int durata, 
                 String matricolaProprietario, String formato, double frequenza, 
                 String testoBrano, LocalDate dataCreazione) {
        super(id, titolo, descrizione, durata, matricolaProprietario, dataCreazione);
        this.formato = formato;
        this.frequenza = frequenza;
        this.testoBrano = testoBrano;
    }

    public String getFormato() { return formato; }
    public double getFrequenza() { return frequenza; }
    public String getTestoBrano() { return testoBrano; }
}