package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class GestorePiattaforma {

    private String urlDatabase;
    private String utenteDatabase;
    private String passwordDatabase;

    // ===== COSTRUTTORE =====
    public GestorePiattaforma(String urlDatabase, String utenteDatabase, String passwordDatabase) {
        this.urlDatabase = urlDatabase;
        this.utenteDatabase = utenteDatabase;
        this.passwordDatabase = passwordDatabase;
    }

    // ===== CONNESSIONE AL DATABASE =====
    private Connection ottieniConnessione() throws SQLException {
        return DriverManager.getConnection(urlDatabase, utenteDatabase, passwordDatabase);
    }

    // ====================================================
    // 1. METODI PER GLI UTENTI
    // ====================================================

    public boolean registraUtente(String matricola, String nomeUtente, String email, String username, String password) {
        String query = "INSERT INTO Utente (Matricola, NomeUtente, Email, Username, Password) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, matricola);
            stmt.setString(2, nomeUtente);
            stmt.setString(3, email);
            stmt.setString(4, username);
            stmt.setString(5, password);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Utente verificaLogin(String matricola, String password) {
        String query = "SELECT * FROM Utente WHERE Matricola = ? AND Password = ?";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, matricola);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Utente(
                            rs.getString("Matricola"),
                            rs.getString("NomeUtente"),
                            rs.getString("Email"),
                            rs.getString("Username"),
                            rs.getString("Password")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ====================================================
    // 2. METODI PER AUDIO
    // ====================================================

    public Audio caricaAudio(String matricola, String titolo, String descrizione, int durata,
                             String formato, double frequenza, String testoBrano) {
        String query = "INSERT INTO Audio (Titolo, Descrizione, Durata, Formato, Frequenza, TestoBrano, Matricola) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, titolo);
            stmt.setString(2, descrizione);
            stmt.setInt(3, durata);
            stmt.setString(4, formato);
            stmt.setDouble(5, frequenza);
            stmt.setString(6, testoBrano);
            stmt.setString(7, matricola);
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    return new Audio(
                            keys.getInt(1), titolo, descrizione, durata,
                            matricola, formato, frequenza, testoBrano
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ====================================================
    // 3. METODI PER VIDEO
    // ====================================================

    public Video caricaVideo(String matricola, String titolo, String descrizione, int durata,
                             String risoluzione, String urlSorgente, int frameRate) {
        String query = "INSERT INTO Video (Titolo, Descrizione, Durata, Risoluzione, UrlSorgente, FrameRate, Matricola) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, titolo);
            stmt.setString(2, descrizione);
            stmt.setInt(3, durata);
            stmt.setString(4, risoluzione);
            stmt.setString(5, urlSorgente);
            stmt.setInt(6, frameRate);
            stmt.setString(7, matricola);
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    return new Video(
                            keys.getInt(1), titolo, descrizione, durata,
                            matricola, risoluzione, urlSorgente, frameRate
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ====================================================
    // 4. METODI PER PLAYLIST PRIVATA
    // ====================================================

    public PlaylistPrivata creaPlaylistPrivata(String matricola, String nome, String pin, String note) {
        String query = "INSERT INTO PlaylistPrivata (Nome, PinAccesso, Note, Matricola) VALUES (?, ?, ?, ?)";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, nome);
            stmt.setString(2, pin);
            stmt.setString(3, note);
            stmt.setString(4, matricola);
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    return new PlaylistPrivata(
                            keys.getInt(1), nome, matricola, pin, note
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ====================================================
    // 5. METODI PER PLAYLIST PUBBLICA
    // ====================================================

    public PlaylistPubblica creaPlaylistPubblica(String matricola, String nome, String tag) {
        String query = "INSERT INTO PlaylistPubblica (Nome, TagRicerca, Matricola) VALUES (?, ?, ?)";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, nome);
            stmt.setString(2, tag);
            stmt.setString(3, matricola);
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    return new PlaylistPubblica(
                            keys.getInt(1), nome, matricola, 0, tag
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ====================================================
    // 6. METODI PER PLAYLIST CONDIVISA
    // ====================================================

    public PlaylistCondivisa creaPlaylistCondivisa(String matricola, String nome) {
        String query = "INSERT INTO PlaylistCondivisa (Nome, Matricola) VALUES (?, ?)";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, nome);
            stmt.setString(2, matricola);
            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    return new PlaylistCondivisa(
                            keys.getInt(1), nome, matricola
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ====================================================
    // 7. METODO PER CONCEDERE ACCESSO (usa stored procedure)
    // ====================================================

    public boolean concediAccesso(String matricolaProprietario, String matricolaAutorizzato, int idPlaylistCondivisa) {
        String query = "CALL sp_ConcediAccesso(?, ?, ?)";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, matricolaProprietario);
            stmt.setString(2, matricolaAutorizzato);
            stmt.setInt(3, idPlaylistCondivisa);
            stmt.execute();
            return true;
        } catch (SQLException e) {
            System.err.println("Errore concessione accesso: " + e.getMessage());
            return false;
        }
    }

    // ====================================================
    // 8. METODO PER AGGIUNGERE ELEMENTO A PLAYLIST (CON CONTROLLO DUPLICATO)
    // ====================================================

    public boolean aggiungiElementoAPlaylist(Utente operatore, Playlist playlist, 
                                             ElementoMultimediale elemento, int ordine) {
        String tabella = determinareTabellaContiene(playlist, elemento);
        if (tabella == null) {
            System.err.println("Errore: tabella non determinata!");
            return false;
        }

        String colonnaPlaylist = "IdPlaylistPrivata";
        if (playlist instanceof PlaylistPubblica) colonnaPlaylist = "IdPlaylistPubblica";
        else if (playlist instanceof PlaylistCondivisa) colonnaPlaylist = "IdPlaylistCondivisa";

        String colonnaElemento = (elemento instanceof Audio) ? "IdAudio" : "IdVideo";

        // ===== CONTROLLA SE L'ELEMENTO È GIÀ PRESENTE =====
        String checkQuery = "SELECT COUNT(*) FROM " + tabella + " WHERE " + colonnaPlaylist + " = ? AND " + colonnaElemento + " = ?";
        try (Connection conn = ottieniConnessione();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
            checkStmt.setInt(1, playlist.getId());
            checkStmt.setInt(2, elemento.getId());
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    System.err.println("Elemento già presente nella playlist!");
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        // ===== INSERISCI L'ELEMENTO =====
        String query = "INSERT INTO " + tabella + " (" + colonnaPlaylist + ", " + colonnaElemento + ", Ordine) VALUES (?, ?, ?)";

        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, playlist.getId());
            stmt.setInt(2, elemento.getId());
            stmt.setInt(3, ordine);
            stmt.executeUpdate();

            if (playlist instanceof PlaylistCondivisa) {
                registraModifica(operatore.getMatricola(), playlist.getId(), "aggiunta_elemento", "completata");
            }
            return true;

        } catch (SQLException e) {
            System.err.println("Errore inserimento in playlist: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private String determinareTabellaContiene(Playlist p, ElementoMultimediale e) {
        if (p instanceof PlaylistPrivata) {
            return (e instanceof Audio) ? "Contiene_Privata_Audio" : "Contiene_Privata_Video";
        } else if (p instanceof PlaylistPubblica) {
            return (e instanceof Audio) ? "Contiene_Pubblica_Audio" : "Contiene_Pubblica_Video";
        } else if (p instanceof PlaylistCondivisa) {
            return (e instanceof Audio) ? "Contiene_Condivisa_Audio" : "Contiene_Condivisa_Video";
        }
        return null;
    }

    // ====================================================
    // 9. METODO PER REGISTRARE MODIFICA
    // ====================================================

    public void registraModifica(String matricola, int idPlaylist, String tipoOperazione, String stato) {
        String query = "CALL sp_RegistraModifica(?, ?, ?, ?)";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, matricola);
            stmt.setInt(2, idPlaylist);
            stmt.setString(3, tipoOperazione);
            stmt.setString(4, stato);
            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ====================================================
    // 10. METODO PER RECUPERARE MODIFICHE DI UN UTENTE
    // ====================================================

    public List<Modifica> getModificheForUser(String matricola) {
        List<Modifica> result = new ArrayList<>();
        String query = "SELECT Matricola, IdPlaylistCondivisa, DataOra, TipoOperazione, Stato " +
                       "FROM Modifica WHERE Matricola = ? ORDER BY DataOra DESC";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, matricola);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(new Modifica(
                            rs.getString("Matricola"),
                            rs.getInt("IdPlaylistCondivisa"),
                            rs.getTimestamp("DataOra").toLocalDateTime(),
                            rs.getString("TipoOperazione"),
                            rs.getString("Stato")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    // ====================================================
    // 11. METODO PER RECUPERARE PLAYLIST DI UN UTENTE
    // ====================================================

    public List<Playlist> getPlaylistsByOwner(String matricola) {
        List<Playlist> result = new ArrayList<>();

        // Playlist Private
        String queryPriv = "SELECT IdPlaylistPrivata, Nome, DataCreazione, PinAccesso, Note, Matricola " +
                           "FROM PlaylistPrivata WHERE Matricola = ?";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(queryPriv)) {
            stmt.setString(1, matricola);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(new PlaylistPrivata(
                            rs.getInt("IdPlaylistPrivata"),
                            rs.getString("Nome"),
                            rs.getString("Matricola"),
                            rs.getString("PinAccesso"),
                            rs.getString("Note")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Playlist Pubbliche
        String queryPub = "SELECT IdPlaylistPubblica, Nome, DataCreazione, NumVisualizzazioni, TagRicerca, Matricola " +
                          "FROM PlaylistPubblica WHERE Matricola = ?";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(queryPub)) {
            stmt.setString(1, matricola);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(new PlaylistPubblica(
                            rs.getInt("IdPlaylistPubblica"),
                            rs.getString("Nome"),
                            rs.getString("Matricola"),
                            rs.getInt("NumVisualizzazioni"),
                            rs.getString("TagRicerca")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Playlist Condivise
        String queryCond = "SELECT IdPlaylistCondivisa, Nome, DataCreazione, Matricola " +
                           "FROM PlaylistCondivisa WHERE Matricola = ?";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(queryCond)) {
            stmt.setString(1, matricola);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(new PlaylistCondivisa(
                            rs.getInt("IdPlaylistCondivisa"),
                            rs.getString("Nome"),
                            rs.getString("Matricola")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return result;
    }

    // ====================================================
    // 12. METODO PER RECUPERARE ELEMENTI DI UNA PLAYLIST
    // ====================================================

    public List<ElementoMultimediale> getElementiPlaylist(Playlist playlist) {
        List<ElementoMultimediale> elementi = new ArrayList<>();

        boolean isPrivata = playlist instanceof PlaylistPrivata;
        boolean isPubblica = playlist instanceof PlaylistPubblica;
        boolean isCondivisa = playlist instanceof PlaylistCondivisa;

        String colonnaPlaylist;
        if (isPrivata) colonnaPlaylist = "IdPlaylistPrivata";
        else if (isPubblica) colonnaPlaylist = "IdPlaylistPubblica";
        else if (isCondivisa) colonnaPlaylist = "IdPlaylistCondivisa";
        else return elementi;

        int idPlaylist = playlist.getId();

        String tableAudio, tableVideo;
        if (isPrivata) {
            tableAudio = "Contiene_Privata_Audio";
            tableVideo = "Contiene_Privata_Video";
        } else if (isPubblica) {
            tableAudio = "Contiene_Pubblica_Audio";
            tableVideo = "Contiene_Pubblica_Video";
        } else {
            tableAudio = "Contiene_Condivisa_Audio";
            tableVideo = "Contiene_Condivisa_Video";
        }

        // Recupera gli Audio
        String queryAudio = "SELECT a.* FROM " + tableAudio + " ca " +
                            "JOIN Audio a ON ca.IdAudio = a.IdAudio " +
                            "WHERE ca." + colonnaPlaylist + " = ? ORDER BY ca.Ordine";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(queryAudio)) {
            stmt.setInt(1, idPlaylist);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    elementi.add(new Audio(
                            rs.getInt("IdAudio"),
                            rs.getString("Titolo"),
                            rs.getString("Descrizione"),
                            rs.getInt("Durata"),
                            rs.getString("Matricola"),
                            rs.getString("Formato"),
                            rs.getDouble("Frequenza"),
                            rs.getString("TestoBrano")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Recupera i Video
        String queryVideo = "SELECT v.* FROM " + tableVideo + " cv " +
                            "JOIN Video v ON cv.IdVideo = v.IdVideo " +
                            "WHERE cv." + colonnaPlaylist + " = ? ORDER BY cv.Ordine";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(queryVideo)) {
            stmt.setInt(1, idPlaylist);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    elementi.add(new Video(
                            rs.getInt("IdVideo"),
                            rs.getString("Titolo"),
                            rs.getString("Descrizione"),
                            rs.getInt("Durata"),
                            rs.getString("Matricola"),
                            rs.getString("Risoluzione"),
                            rs.getString("UrlSorgente"),
                            rs.getInt("FrameRate")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return elementi;
    }

    // ====================================================
    // 13. METODO PER RECUPERARE UN ELEMENTO PER ID
    // ====================================================

    public ElementoMultimediale getElementoById(int id) {
        // Cerca tra gli Audio
        String queryAudio = "SELECT * FROM Audio WHERE IdAudio = ?";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(queryAudio)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Audio(
                            rs.getInt("IdAudio"),
                            rs.getString("Titolo"),
                            rs.getString("Descrizione"),
                            rs.getInt("Durata"),
                            rs.getString("Matricola"),
                            rs.getString("Formato"),
                            rs.getDouble("Frequenza"),
                            rs.getString("TestoBrano")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Cerca tra i Video
        String queryVideo = "SELECT * FROM Video WHERE IdVideo = ?";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(queryVideo)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Video(
                            rs.getInt("IdVideo"),
                            rs.getString("Titolo"),
                            rs.getString("Descrizione"),
                            rs.getInt("Durata"),
                            rs.getString("Matricola"),
                            rs.getString("Risoluzione"),
                            rs.getString("UrlSorgente"),
                            rs.getInt("FrameRate")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    // ====================================================
    // 14. METODO PER RECUPERARE I CONTENUTI DI UN UTENTE
    // ====================================================

    public List<ElementoMultimediale> getContenutiByOwner(String matricola) {
        List<ElementoMultimediale> result = new ArrayList<>();

        String queryAudio = "SELECT * FROM Audio WHERE Matricola = ?";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(queryAudio)) {
            stmt.setString(1, matricola);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(new Audio(
                            rs.getInt("IdAudio"),
                            rs.getString("Titolo"),
                            rs.getString("Descrizione"),
                            rs.getInt("Durata"),
                            rs.getString("Matricola"),
                            rs.getString("Formato"),
                            rs.getDouble("Frequenza"),
                            rs.getString("TestoBrano")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String queryVideo = "SELECT * FROM Video WHERE Matricola = ?";
        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(queryVideo)) {
            stmt.setString(1, matricola);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(new Video(
                            rs.getInt("IdVideo"),
                            rs.getString("Titolo"),
                            rs.getString("Descrizione"),
                            rs.getInt("Durata"),
                            rs.getString("Matricola"),
                            rs.getString("Risoluzione"),
                            rs.getString("UrlSorgente"),
                            rs.getInt("FrameRate")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return result;
    }

    // ====================================================
    // 15. METODO PER RIMUOVERE ELEMENTO DA PLAYLIST
    // ====================================================

    public boolean rimuoviElementoDaPlaylist(Utente operatore, Playlist playlist, ElementoMultimediale elemento) {
        String tabella = determinareTabellaContiene(playlist, elemento);
        if (tabella == null) return false;

        String colonnaPlaylist = "IdPlaylistPrivata";
        if (playlist instanceof PlaylistPubblica) colonnaPlaylist = "IdPlaylistPubblica";
        else if (playlist instanceof PlaylistCondivisa) colonnaPlaylist = "IdPlaylistCondivisa";

        String colonnaElemento = (elemento instanceof Audio) ? "IdAudio" : "IdVideo";
        String query = "DELETE FROM " + tabella + " WHERE " + colonnaPlaylist + " = ? AND " + colonnaElemento + " = ?";

        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, playlist.getId());
            stmt.setInt(2, elemento.getId());
            int rows = stmt.executeUpdate();

            if (rows > 0 && playlist instanceof PlaylistCondivisa) {
                registraModifica(operatore.getMatricola(), playlist.getId(), "rimozione_elemento", "completata");
            }

            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Errore rimozione da playlist: " + e.getMessage());
            return false;
        }
    }

    // ====================================================
    // 16. METODO PER AGGIORNARE L'ORDINE DI UN ELEMENTO
    // ====================================================

    public boolean aggiornaOrdineElemento(Playlist playlist, int idElemento, int nuovoOrdine) {
        String tabella;
        String colonnaPlaylist;
        String colonnaElemento;

        if (playlist instanceof PlaylistPrivata) {
            colonnaPlaylist = "IdPlaylistPrivata";
            tabella = "Contiene_Privata_";
        } else if (playlist instanceof PlaylistPubblica) {
            colonnaPlaylist = "IdPlaylistPubblica";
            tabella = "Contiene_Pubblica_";
        } else if (playlist instanceof PlaylistCondivisa) {
            colonnaPlaylist = "IdPlaylistCondivisa";
            tabella = "Contiene_Condivisa_";
        } else {
            return false;
        }

        // Determina se è Audio o Video
        ElementoMultimediale elem = getElementoById(idElemento);
        if (elem == null) return false;

        if (elem instanceof Audio) {
            tabella += "Audio";
            colonnaElemento = "IdAudio";
        } else {
            tabella += "Video";
            colonnaElemento = "IdVideo";
        }

        String query = "UPDATE " + tabella + " SET Ordine = ? WHERE " + colonnaPlaylist + " = ? AND " + colonnaElemento + " = ?";

        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, nuovoOrdine);
            stmt.setInt(2, playlist.getId());
            stmt.setInt(3, idElemento);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ====================================================
    // 17. METODO PER AVVIARE LA RIPRODUZIONE
    // ====================================================

    public boolean avviaRiproduzione(String matricolaUtente, ElementoMultimediale elemento) {
        String query;
        if (elemento instanceof Audio) {
            query = "INSERT INTO Riproduzione_Audio (Matricola, IdAudio) VALUES (?, ?)";
        } else {
            query = "INSERT INTO Riproduzione_Video (Matricola, IdVideo) VALUES (?, ?)";
        }

        try (Connection conn = ottieniConnessione();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, matricolaUtente);
            stmt.setInt(2, elemento.getId());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
