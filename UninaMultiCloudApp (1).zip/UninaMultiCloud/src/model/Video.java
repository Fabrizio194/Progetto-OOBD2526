package model;

import java.time.LocalDate;

public class Video extends ElementoMultimediale {
    private String risoluzione;
    private String urlSorgente;
    private int frameRate;

    // Costruttore senza dataCreazione
    public Video(int id, String titolo, String descrizione, int durata, 
                 String matricolaProprietario, String risoluzione, String urlSorgente, int frameRate) {
        this(id, titolo, descrizione, durata, matricolaProprietario, risoluzione, urlSorgente, frameRate, LocalDate.now());
    }

    // Costruttore completo con dataCreazione
    public Video(int id, String titolo, String descrizione, int durata, 
                 String matricolaProprietario, String risoluzione, String urlSorgente, 
                 int frameRate, LocalDate dataCreazione) {
        super(id, titolo, descrizione, durata, matricolaProprietario, dataCreazione);
        this.risoluzione = risoluzione;
        this.urlSorgente = urlSorgente;
        this.frameRate = frameRate;
    }

    public String getRisoluzione() { return risoluzione; }
    public String getUrlSorgente() { return urlSorgente; }
    public int getFrameRate() { return frameRate; }
}