package model;

import java.time.LocalDate;

public abstract class ElementoMultimediale {
    private int id;
    private String titolo;
    private String descrizione;
    private int durata;
    private String matricolaProprietario;
    private LocalDate dataCreazione;  // ← AGGIUNTO

    // Costruttore senza dataCreazione (usa data corrente)
    public ElementoMultimediale(int id, String titolo, String descrizione, int durata, String matricolaProprietario) {
        this(id, titolo, descrizione, durata, matricolaProprietario, LocalDate.now());
    }

    // Costruttore completo con dataCreazione
    public ElementoMultimediale(int id, String titolo, String descrizione, int durata, 
                                String matricolaProprietario, LocalDate dataCreazione) {
        this.id = id;
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.durata = durata;
        this.matricolaProprietario = matricolaProprietario;
        this.dataCreazione = dataCreazione != null ? dataCreazione : LocalDate.now();
    }

    // ===== GETTER =====
    public int getId() { return id; }
    public String getTitolo() { return titolo; }
    public String getDescrizione() { return descrizione; }
    public int getDurata() { return durata; }
    public String getMatricolaProprietario() { return matricolaProprietario; }
    public LocalDate getDataCreazione() { return dataCreazione; }  // ← AGGIUNTO
}