package GUI;

import java.awt.*;
import javax.swing.*;
import model.GestorePiattaforma;
import model.Utente;

public class HomeFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;

    public HomeFrame(Utente utente, GestorePiattaforma gestore) {
        this.utente = utente;
        this.gestore = gestore;
        setTitle("UninaMultiCloud - Home");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== TITOLO =====
        JLabel title = new JLabel("HOME FRAME", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        // ===== PANNEL BOTTONI (4 PULSANTI) =====
        JPanel pnlBottoni = new JPanel(new GridLayout(4, 1, 10, 10));
        pnlBottoni.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JButton btnPlaylist = new JButton("ACCESSO PLAYLIST");
        JButton btnModifiche = new JButton("GESTIONE MODIFICHE");
        JButton btnUpload = new JButton("+ UPLOAD CONTENUTO");
        JButton btnMieiContenuti = new JButton("📁 I MIEI CONTENUTI");

        pnlBottoni.add(btnPlaylist);
        pnlBottoni.add(btnModifiche);
        pnlBottoni.add(btnUpload);
        pnlBottoni.add(btnMieiContenuti);
        add(pnlBottoni, BorderLayout.CENTER);

        // ===== INFO UTENTE =====
        JLabel info = new JLabel("Utente: " + utente.getNomeUtente() + " (" + utente.getMatricola() + ")", SwingConstants.CENTER);
        add(info, BorderLayout.SOUTH);

        // ===== EVENTI =====
        btnPlaylist.addActionListener(e -> new PlaylistFrame(utente, gestore));
        btnModifiche.addActionListener(e -> new ModificheFrame(utente, gestore));
        btnUpload.addActionListener(e -> new UploadContentFrame(utente, gestore));
        btnMieiContenuti.addActionListener(e -> new MieiContenutiFrame(utente, gestore));

        setVisible(true);
    }
}