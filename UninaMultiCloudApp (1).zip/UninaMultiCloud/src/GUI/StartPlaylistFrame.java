package GUI;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import model.GestorePiattaforma;
import model.Playlist;
import model.Utente;
import model.ElementoMultimediale;
import model.Audio;
import model.Video;

public class StartPlaylistFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;
    private Playlist playlist;
    private List<ElementoMultimediale> coda;
    private int indiceCorrente = 0;
    private JLabel lblDisplay;
    private JButton btnPrev, btnPlayPause, btnNext;
    private JList<String> listCoda;
    private DefaultListModel<String> listModel;
    private boolean inRiproduzione = false;

    public StartPlaylistFrame(Utente utente, GestorePiattaforma gestore, Playlist playlist) {
        this.utente = utente;
        this.gestore = gestore;
        this.playlist = playlist;
        setTitle("Riproduzione");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        lblDisplay = new JLabel("Nessun contenuto in riproduzione", SwingConstants.CENTER);
        lblDisplay.setFont(new Font("Arial", Font.BOLD, 18));
        lblDisplay.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(lblDisplay, BorderLayout.CENTER);

        JPanel pnlCoda = new JPanel(new BorderLayout());
        pnlCoda.setBorder(BorderFactory.createTitledBorder("Coda riproduzione"));
        listModel = new DefaultListModel<>();
        listCoda = new JList<>(listModel);
        pnlCoda.add(new JScrollPane(listCoda), BorderLayout.CENTER);
        add(pnlCoda, BorderLayout.EAST);

        JPanel pnlControlli = new JPanel(new FlowLayout());
        btnPrev = new JButton("<< PREV");
        btnPlayPause = new JButton("PLAY/PAUSE");
        btnNext = new JButton("NEXT >>");
        pnlControlli.add(btnPrev);
        pnlControlli.add(btnPlayPause);
        pnlControlli.add(btnNext);
        add(pnlControlli, BorderLayout.SOUTH);

        if (playlist != null) {
            coda = gestore.getElementiPlaylist(playlist);
            if (coda != null && !coda.isEmpty()) {
                indiceCorrente = 0;
                aggiornaDisplay();
                aggiornaCoda();
            } else {
                lblDisplay.setText("Playlist vuota");
                btnPrev.setEnabled(false);
                btnPlayPause.setEnabled(false);
                btnNext.setEnabled(false);
            }
        } else {
            lblDisplay.setText("Seleziona una playlist da riprodurre");
            btnPrev.setEnabled(false);
            btnPlayPause.setEnabled(false);
            btnNext.setEnabled(false);
        }

        btnPrev.addActionListener(e -> prev());
        btnPlayPause.addActionListener(e -> playPause());
        btnNext.addActionListener(e -> next());

        setVisible(true);
    }

    private void aggiornaDisplay() {
        if (coda == null || coda.isEmpty() || indiceCorrente >= coda.size()) {
            lblDisplay.setText("Fine della coda");
            return;
        }
        ElementoMultimediale elem = coda.get(indiceCorrente);
        String info = elem.getTitolo() + " (" + elem.getClass().getSimpleName() + ")";
        if (elem instanceof Audio) {
            Audio a = (Audio) elem;
            info += "\nFormato: " + a.getFormato() + ", Frequenza: " + a.getFrequenza();
        } else if (elem instanceof Video) {
            Video v = (Video) elem;
            info += "\nRisoluzione: " + v.getRisoluzione() + ", FrameRate: " + v.getFrameRate();
        }
        lblDisplay.setText("<html>" + info.replace("\n", "<br>") + "</html>");
        listCoda.setSelectedIndex(indiceCorrente);
    }

    private void aggiornaCoda() {
        listModel.clear();
        if (coda == null) return;
        for (int i = 0; i < coda.size(); i++) {
            ElementoMultimediale e = coda.get(i);
            String prefix = (i == indiceCorrente) ? "-> " : (i < indiceCorrente ? "   " : "   ");
            listModel.addElement(prefix + (i+1) + ". " + e.getTitolo());
        }
    }

    private void prev() {
        if (indiceCorrente > 0) {
            indiceCorrente--;
            aggiornaDisplay();
            aggiornaCoda();
        } else {
            JOptionPane.showMessageDialog(this, "Sei all'inizio della coda.");
        }
    }

    private void playPause() {
        if (coda == null || coda.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nessun contenuto da riprodurre.");
            return;
        }
        inRiproduzione = !inRiproduzione;
        btnPlayPause.setText(inRiproduzione ? "PAUSA" : "PLAY");
        if (inRiproduzione) {
            lblDisplay.setBackground(Color.GREEN);
        } else {
            lblDisplay.setBackground(null);
        }
    }

    private void next() {
        if (indiceCorrente < coda.size() - 1) {
            indiceCorrente++;
            aggiornaDisplay();
            aggiornaCoda();
        } else {
            JOptionPane.showMessageDialog(this, "Fine della coda.");
        }
    }


public void setCoda(List<ElementoMultimediale> coda) {
    this.coda = coda;
    if (coda != null && !coda.isEmpty()) {
        indiceCorrente = 0;
        aggiornaDisplay();
        aggiornaCoda();
        btnPrev.setEnabled(true);
        btnPlayPause.setEnabled(true);
        btnNext.setEnabled(true);
    } else {
        lblDisplay.setText("Nessun contenuto in coda");
        btnPrev.setEnabled(false);
        btnPlayPause.setEnabled(false);
        btnNext.setEnabled(false);
    }
}
}
