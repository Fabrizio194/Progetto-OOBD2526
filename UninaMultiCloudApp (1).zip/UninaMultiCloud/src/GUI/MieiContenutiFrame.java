package GUI;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Audio;
import model.ElementoMultimediale;
import model.GestorePiattaforma;
import model.Playlist;
import model.PlaylistPrivata;
import model.PlaylistPubblica;
import model.PlaylistCondivisa;
import model.Utente;
import model.Video;

public class MieiContenutiFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;
    private JTable tabellaContenuti;
    private DefaultTableModel modelContenuti;
    private JButton btnRiproduci, btnAggiungiAPlaylist, btnAggiorna, btnChiudi, btnCreaPlaylist;
    private JComboBox<String> cmbPlaylist;
    private JComboBox<String> cmbTipoPlaylist;

    public MieiContenutiFrame(Utente utente, GestorePiattaforma gestore) {
        this.utente = utente;
        this.gestore = gestore;
        setTitle("I Miei Contenuti - " + utente.getNomeUtente());
        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // ===== TABELLA CONTENUTI =====
        modelContenuti = new DefaultTableModel(new String[]{"ID", "Titolo", "Tipo", "Durata (s)", "Data Creazione"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabellaContenuti = new JTable(modelContenuti);
        tabellaContenuti.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(tabellaContenuti);
        scroll.setBorder(BorderFactory.createTitledBorder("I tuoi contenuti caricati"));
        add(scroll, BorderLayout.CENTER);

        // ===== PANNEL INFERIORE: BOTTONI E COMBOBOX =====
        JPanel pnlBottoni = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 8));

        btnRiproduci = new JButton("▶ RIPRODUCI");
        btnAggiungiAPlaylist = new JButton("➕ AGGIUNGI A PLAYLIST");
        btnAggiorna = new JButton("🔄 AGGIORNA");
        btnChiudi = new JButton("✖ CHIUDI");
        btnCreaPlaylist = new JButton("➕ NUOVA PLAYLIST");

        pnlBottoni.add(btnRiproduci);
        pnlBottoni.add(btnAggiungiAPlaylist);
        
        pnlBottoni.add(new JLabel("   Playlist:"));
        cmbPlaylist = new JComboBox<>();
        cmbPlaylist.setPreferredSize(new Dimension(200, 25));
        pnlBottoni.add(cmbPlaylist);
        
        pnlBottoni.add(new JLabel("   Tipo:"));
        cmbTipoPlaylist = new JComboBox<>(new String[]{"Privata", "Pubblica", "Condivisa"});
        cmbTipoPlaylist.setPreferredSize(new Dimension(100, 25));
        pnlBottoni.add(cmbTipoPlaylist);
        
        pnlBottoni.add(btnCreaPlaylist);
        pnlBottoni.add(btnAggiorna);
        pnlBottoni.add(btnChiudi);

        add(pnlBottoni, BorderLayout.SOUTH);

        // ===== CARICAMENTO INIZIALE =====
        caricaContenuti();
        caricaPlaylist();

        // ===== EVENTI =====
        btnRiproduci.addActionListener(e -> riproduciContenuto());
        btnAggiungiAPlaylist.addActionListener(e -> aggiungiAPlaylist());
        btnAggiorna.addActionListener(e -> {
            caricaContenuti();
            caricaPlaylist();
            JOptionPane.showMessageDialog(this, "Contenuti e playlist aggiornati!");
        });
        btnChiudi.addActionListener(e -> dispose());
        btnCreaPlaylist.addActionListener(e -> creaNuovaPlaylist());

        setVisible(true);
    }

    private void caricaContenuti() {
        modelContenuti.setRowCount(0);
        List<ElementoMultimediale> contenuti = gestore.getContenutiByOwner(utente.getMatricola());

        for (ElementoMultimediale e : contenuti) {
            String tipo = (e instanceof Audio) ? "Audio" : "Video";
            String dataCreazione = "-";
            if (e.getDataCreazione() != null) {
                dataCreazione = e.getDataCreazione().toString();
            }
            modelContenuti.addRow(new Object[]{
                e.getId(),
                e.getTitolo(),
                tipo,
                e.getDurata(),
                dataCreazione
            });
        }

        if (modelContenuti.getRowCount() == 0) {
            modelContenuti.addRow(new Object[]{"-", "Nessun contenuto caricato", "-", "-", "-"});
        }
    }

    private void caricaPlaylist() {
        cmbPlaylist.removeAllItems();
        List<Playlist> playlists = gestore.getPlaylistsByOwner(utente.getMatricola());

        if (playlists.isEmpty()) {
            cmbPlaylist.addItem("Nessuna playlist disponibile");
        } else {
            for (Playlist p : playlists) {
                String tipo = "";
                if (p instanceof PlaylistPrivata) tipo = "(Privata)";
                else if (p instanceof PlaylistPubblica) tipo = "(Pubblica)";
                else if (p instanceof PlaylistCondivisa) tipo = "(Condivisa)";
                cmbPlaylist.addItem(p.getId() + " - " + p.getNome() + " " + tipo);
            }
        }
    }

    private void riproduciContenuto() {
        int row = tabellaContenuti.getSelectedRow();
        if (row == -1 || modelContenuti.getValueAt(row, 0).equals("-")) {
            JOptionPane.showMessageDialog(this, "Seleziona un contenuto da riprodurre.");
            return;
        }

        int id = (int) modelContenuti.getValueAt(row, 0);
        ElementoMultimediale elemento = gestore.getElementoById(id);

        if (elemento != null) {
            gestore.avviaRiproduzione(utente.getMatricola(), elemento);
            
            List<ElementoMultimediale> coda = new java.util.ArrayList<>();
            coda.add(elemento);
            
            StartPlaylistFrame frame = new StartPlaylistFrame(utente, gestore, null);
            frame.setCoda(coda);
            frame.setVisible(true);
            
            JOptionPane.showMessageDialog(this, "Riproduzione avviata per: " + elemento.getTitolo());
        } else {
            JOptionPane.showMessageDialog(this, "Errore: contenuto non trovato.");
        }
    }

    private void aggiungiAPlaylist() {
        int rowContenuto = tabellaContenuti.getSelectedRow();
        if (rowContenuto == -1 || modelContenuti.getValueAt(rowContenuto, 0).equals("-")) {
            JOptionPane.showMessageDialog(this, "Seleziona un contenuto da aggiungere.");
            return;
        }

        int selectedIndex = cmbPlaylist.getSelectedIndex();
        if (selectedIndex == -1 || cmbPlaylist.getItemAt(selectedIndex).startsWith("Nessuna")) {
            JOptionPane.showMessageDialog(this, "Nessuna playlist disponibile. Crea prima una playlist.");
            return;
        }

        String item = cmbPlaylist.getItemAt(selectedIndex);
        int idPlaylist = Integer.parseInt(item.split(" - ")[0]);

        int idElemento = (int) modelContenuti.getValueAt(rowContenuto, 0);
        ElementoMultimediale elemento = gestore.getElementoById(idElemento);

        if (elemento == null) {
            JOptionPane.showMessageDialog(this, "Errore: contenuto non trovato (ID: " + idElemento + ").");
            return;
        }

        List<Playlist> playlists = gestore.getPlaylistsByOwner(utente.getMatricola());
        Playlist playlistScelta = null;
        for (Playlist p : playlists) {
            if (p.getId() == idPlaylist) {
                playlistScelta = p;
                break;
            }
        }

        if (playlistScelta == null) {
            JOptionPane.showMessageDialog(this, "Errore: playlist non trovata (ID: " + idPlaylist + ").");
            return;
        }

        // ===== CONTROLLO: ELEMENTO GIÀ PRESENTE =====
        List<ElementoMultimediale> elementiEsistenti = gestore.getElementiPlaylist(playlistScelta);
        for (ElementoMultimediale e : elementiEsistenti) {
            if (e.getId() == idElemento) {
                JOptionPane.showMessageDialog(this, 
                    "⚠️ Il contenuto \"" + elemento.getTitolo() + "\" è già presente nella playlist \"" + playlistScelta.getNome() + "\".",
                    "Contenuto già presente",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        int nuovoOrdine = elementiEsistenti.size() + 1;

        boolean ok = gestore.aggiungiElementoAPlaylist(utente, playlistScelta, elemento, nuovoOrdine);
        if (ok) {
            JOptionPane.showMessageDialog(this, "✅ Contenuto \"" + elemento.getTitolo() + 
                                         "\" aggiunto alla playlist \"" + playlistScelta.getNome() + "\"!");
            caricaContenuti();
        } else {
            JOptionPane.showMessageDialog(this, "❌ Errore durante l'aggiunta alla playlist.", 
                                         "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void creaNuovaPlaylist() {
        String tipo = (String) cmbTipoPlaylist.getSelectedItem();
        String nome = JOptionPane.showInputDialog(this, "Inserisci il nome della nuova playlist:");
        
        if (nome == null || nome.trim().isEmpty()) {
            return;
        }
        
        nome = nome.trim();
        Playlist nuovaPlaylist = null;
        
        if (tipo.equals("Privata")) {
            String pin = JOptionPane.showInputDialog(this, "Inserisci un PIN (4 cifre, opzionale):");
            String note = JOptionPane.showInputDialog(this, "Inserisci una nota (opzionale):");
            nuovaPlaylist = gestore.creaPlaylistPrivata(utente.getMatricola(), nome, pin, note);
        } else if (tipo.equals("Pubblica")) {
            String tag = JOptionPane.showInputDialog(this, "Inserisci un tag di ricerca (opzionale):");
            nuovaPlaylist = gestore.creaPlaylistPubblica(utente.getMatricola(), nome, tag);
        } else if (tipo.equals("Condivisa")) {
            nuovaPlaylist = gestore.creaPlaylistCondivisa(utente.getMatricola(), nome);
        }
        
        if (nuovaPlaylist != null) {
            JOptionPane.showMessageDialog(this, "✅ Playlist \"" + nome + "\" creata con successo!");
            caricaPlaylist();
        } else {
            JOptionPane.showMessageDialog(this, "❌ Errore nella creazione della playlist.", 
                                         "Errore", JOptionPane.ERROR_MESSAGE);
        }
    }
}