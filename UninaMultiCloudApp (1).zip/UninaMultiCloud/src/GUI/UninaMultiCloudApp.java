package GUI;

import javax.swing.SwingUtilities;
import model.GestorePiattaforma;

public class UninaMultiCloudApp {
    public static void main(String[] args) {
        // ===== PARAMETRI DI CONNESSIONE A MYSQL =====
        String url = "jdbc:mysql://localhost:3306/UninaMultiCloud?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        String user = "root";          // Nome utente MySQL (di solito 'root')
        String password = "TantoMiBoccia10.";  // La password che hai impostato durante l'installazione
        // ============================================
        
        // Crea il gestore con la connessione al database
        GestorePiattaforma gestore = new GestorePiattaforma(url, user, password);
        
        // Avvia la GUI
        SwingUtilities.invokeLater(() -> new LoginFrame(gestore));
    }
}