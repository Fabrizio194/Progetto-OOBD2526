package GUI;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.GestorePiattaforma;
import model.Playlist;
import model.PlaylistPubblica;
import model.PlaylistPrivata;
import model.PlaylistCondivisa;
import model.Utente;

public class PlaylistFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;
    private JComboBox<String> cmbFiltro;
    private JTable tabellaPlaylist;
    private DefaultTableModel model;

    public PlaylistFrame(Utente utente, GestorePiattaforma gestore) {
        this.utente = utente;
        this.gestore = gestore;
        setTitle("Playlist - " + utente.getNomeUtente());
        setSize(650, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // ===== PANNEL FILTRO =====
        JPanel pnlFiltro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlFiltro.add(new JLabel("Filtra:"));
        cmbFiltro = new JComboBox<>(new String[]{"Tutte le Playlist", "Pubbliche", "Private", "Condivise"});
        pnlFiltro.add(cmbFiltro);
        JButton btnFiltra = new JButton("Applica");
        pnlFiltro.add(btnFiltra);
        add(pnlFiltro, BorderLayout.NORTH);

        // ===== TABELLA PLAYLIST =====
        model = new DefaultTableModel(new String[]{"Nome", "Tipo", "Metadati"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabellaPlaylist = new JTable(model);
        tabellaPlaylist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(tabellaPlaylist);
        add(scroll, BorderLayout.CENTER);

        // ===== PANNEL BOTTONI =====
        JPanel pnlBottoni = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton btnNuova = new JButton("+ NEW PLAYLIST");
        JButton btnRiproduci = new JButton("▶ RIPRODUCI");
        JButton btnModifica = new JButton("✏️ MODIFICA");
        JButton btnMieiContenuti = new JButton("📁 I MIEI CONTENUTI");
        pnlBottoni.add(btnNuova);
        pnlBottoni.add(btnRiproduci);
        pnlBottoni.add(btnModifica);
        pnlBottoni.add(btnMieiContenuti);
        add(pnlBottoni, BorderLayout.SOUTH);

        // ===== CARICAMENTO INIZIALE =====
        caricaPlaylist("Tutte le Playlist");

        // ===== EVENTI =====
        btnFiltra.addActionListener(e -> caricaPlaylist((String) cmbFiltro.getSelectedItem()));
        btnNuova.addActionListener(e -> new NewPlaylistFrame(utente, gestore, this));
        btnRiproduci.addActionListener(e -> avviaRiproduzione());
        btnModifica.addActionListener(e -> apriModificaPlaylist());
        btnMieiContenuti.addActionListener(e -> new MieiContenutiFrame(utente, gestore));

        setVisible(true);
    }

    // ====================================================
    // METODO: CARICA PLAYLIST (PUBLIC per accesso esterno)
    // ====================================================
    public void caricaPlaylist(String filtro) {
        model.setRowCount(0);
        List<Playlist> lista = gestore.getPlaylistsByOwner(utente.getMatricola());

        String tipoFiltro = null;
        if (filtro.equals("Pubbliche")) {
            tipoFiltro = "Pubblica";
        } else if (filtro.equals("Private")) {
            tipoFiltro = "Privata";
        } else if (filtro.equals("Condivise")) {
            tipoFiltro = "Condivisa";
        }

        for (Playlist p : lista) {
            String tipo;
            String metadati = "";

            if (p instanceof PlaylistPubblica) {
                tipo = "Pubblica";
                PlaylistPubblica pp = (PlaylistPubblica) p;
                metadati = "Vis: " + pp.getNumVisualizzazioni() + ", Tag: " + pp.getTagRicerca();
            } else if (p instanceof PlaylistPrivata) {
                tipo = "Privata";
                PlaylistPrivata pr = (PlaylistPrivata) p;
                metadati = "Note: " + (pr.getNote() != null && !pr.getNote().isEmpty() ? pr.getNote() : "nessuna");
            } else if (p instanceof PlaylistCondivisa) {
                tipo = "Condivisa";
                metadati = "Condivisa con altri";
            } else {
                tipo = "Sconosciuto";
            }

            if (!filtro.equals("Tutte le Playlist") && !tipo.equals(tipoFiltro)) {
                continue;
            }

            model.addRow(new Object[]{p.getNome(), tipo, metadati});
        }
    }

    // ====================================================
    // METODO: AVVIA RIPRODUZIONE
    // ====================================================
    private void avviaRiproduzione() {
        int row = tabellaPlaylist.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleziona una playlist.");
            return;
        }

        String nome = (String) model.getValueAt(row, 0);
        List<Playlist> lista = gestore.getPlaylistsByOwner(utente.getMatricola());

        Playlist scelta = null;
        for (Playlist p : lista) {
            if (p.getNome().equals(nome)) {
                scelta = p;
                break;
            }
        }

        if (scelta != null) {
            new StartPlaylistFrame(utente, gestore, scelta);
        } else {
            JOptionPane.showMessageDialog(this, "Errore: playlist non trovata.");
        }
    }

    // ====================================================
    // METODO: APRI MODIFICA PLAYLIST (PRIVATE E CONDIVISE)
    // ====================================================
    private void apriModificaPlaylist() {
        int row = tabellaPlaylist.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleziona una playlist.");
            return;
        }

        String nome = (String) model.getValueAt(row, 0);
        String tipo = (String) model.getValueAt(row, 1);

        // Permette modifica per playlist Private e Condivise (non Pubbliche)
        if (!tipo.equals("Condivisa") && !tipo.equals("Privata")) {
            JOptionPane.showMessageDialog(this, "Solo le playlist condivise e private possono essere modificate.");
            return;
        }

        List<Playlist> lista = gestore.getPlaylistsByOwner(utente.getMatricola());
        Playlist scelta = null;
        for (Playlist p : lista) {
            if (p.getNome().equals(nome)) {
                scelta = p;
                break;
            }
        }

        if (scelta != null) {
            // Passa la Playlist generica (polimorfismo)
            new GestisciPlaylistFrame(utente, gestore, scelta, this);
        } else {
            JOptionPane.showMessageDialog(this, "Errore: playlist non trovata.");
        }
    }
}