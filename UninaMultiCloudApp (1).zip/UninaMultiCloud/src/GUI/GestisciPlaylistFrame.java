package GUI;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Audio;
import model.ElementoMultimediale;
import model.GestorePiattaforma;
import model.Playlist;
import model.Utente;
import model.Video;

public class GestisciPlaylistFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private Utente utente;
    private GestorePiattaforma gestore;
    private Playlist playlist;
    private PlaylistFrame parent;
    private JTable tabellaElementi;
    private DefaultTableModel modelElementi;
    private JComboBox<String> cmbContenutiDisponibili;
    private JButton btnAggiungi, btnRimuovi, btnSalvaOrdine, btnChiudi;

    public GestisciPlaylistFrame(Utente utente, GestorePiattaforma gestore, 
                                 Playlist playlist, PlaylistFrame parent) {
        this.utente = utente;
        this.gestore = gestore;
        this.playlist = playlist;
        this.parent = parent;

        String tipo = "";
        if (playlist instanceof model.PlaylistPrivata) tipo = "Privata";
        else if (playlist instanceof model.PlaylistPubblica) tipo = "Pubblica";
        else if (playlist instanceof model.PlaylistCondivisa) tipo = "Condivisa";

        setTitle("Modifica Playlist " + tipo + ": " + playlist.getNome());
        setSize(700, 500);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel pnlInfo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlInfo.add(new JLabel("Playlist: " + playlist.getNome()));
        pnlInfo.add(new JLabel(" | Tipo: " + tipo));
        pnlInfo.add(new JLabel(" | Proprietario: " + playlist.getMatricolaProprietario()));
        pnlInfo.add(new JLabel(" | ID: " + playlist.getId()));
        add(pnlInfo, BorderLayout.NORTH);

        modelElementi = new DefaultTableModel(new String[]{"ID", "Titolo", "Tipo", "Durata", "Ordine"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4;
            }
        };
        tabellaElementi = new JTable(modelElementi);
        tabellaElementi.getColumnModel().getColumn(4).setPreferredWidth(60);
        JScrollPane scroll = new JScrollPane(tabellaElementi);
        scroll.setBorder(BorderFactory.createTitledBorder("Elementi nella playlist"));
        add(scroll, BorderLayout.CENTER);

        JPanel pnlContenuti = new JPanel(new BorderLayout(5, 5));
        pnlContenuti.setBorder(BorderFactory.createTitledBorder("Contenuti disponibili"));
        pnlContenuti.setPreferredSize(new Dimension(200, 0));

        cmbContenutiDisponibili = new JComboBox<>();
        pnlContenuti.add(cmbContenutiDisponibili, BorderLayout.CENTER);

        btnAggiungi = new JButton("+ AGGIUNGI");
        pnlContenuti.add(btnAggiungi, BorderLayout.SOUTH);
        add(pnlContenuti, BorderLayout.EAST);

        JPanel pnlBottoni = new JPanel(new FlowLayout());
        btnRimuovi = new JButton("RIMUOVI SELEZIONATO");
        btnSalvaOrdine = new JButton("SALVA ORDINE");
        btnChiudi = new JButton("CHIUDI");
        pnlBottoni.add(btnRimuovi);
        pnlBottoni.add(btnSalvaOrdine);
        pnlBottoni.add(btnChiudi);
        add(pnlBottoni, BorderLayout.SOUTH);

        caricaElementiPlaylist();
        caricaContenutiDisponibili();

        btnAggiungi.addActionListener(e -> aggiungiElemento());
        btnRimuovi.addActionListener(e -> rimuoviElemento());
        btnSalvaOrdine.addActionListener(e -> salvaOrdine());
        btnChiudi.addActionListener(e -> {
            if (parent != null) {
                parent.caricaPlaylist("Tutte le Playlist");
            }
            dispose();
        });

        setVisible(true);
    }

    private void caricaElementiPlaylist() {
        modelElementi.setRowCount(0);
        List<ElementoMultimediale> elementi = gestore.getElementiPlaylist(playlist);

        int ordine = 1;
        for (ElementoMultimediale e : elementi) {
            String tipo = (e instanceof Audio) ? "Audio" : "Video";
            modelElementi.addRow(new Object[]{
                e.getId(),
                e.getTitolo(),
                tipo,
                e.getDurata(),
                ordine++
            });
        }
    }

    private void caricaContenutiDisponibili() {
        cmbContenutiDisponibili.removeAllItems();
        
        List<ElementoMultimediale> contenuti = gestore.getContenutiByOwner(utente.getMatricola());
        if (contenuti.isEmpty()) {
            cmbContenutiDisponibili.addItem("Nessun contenuto disponibile");
            return;
        }
        
        List<ElementoMultimediale> elementiEsistenti = gestore.getElementiPlaylist(playlist);
        
        boolean trovato = false;
        for (ElementoMultimediale e : contenuti) {
            boolean giaPresente = false;
            for (ElementoMultimediale es : elementiEsistenti) {
                if (es.getId() == e.getId()) {
                    giaPresente = true;
                    break;
                }
            }
            if (!giaPresente) {
                String tipo = (e instanceof Audio) ? "Audio" : "Video";
                cmbContenutiDisponibili.addItem(e.getId() + " - " + e.getTitolo() + " (" + tipo + ")");
                trovato = true;
            }
        }
        
        if (!trovato) {
            cmbContenutiDisponibili.addItem("Tutti i contenuti sono già nella playlist");
        }
    }

    private void aggiungiElemento() {
        int selectedIndex = cmbContenutiDisponibili.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Nessun contenuto disponibile da aggiungere.");
            return;
        }

        String item = (String) cmbContenutiDisponibili.getSelectedItem();
        if (item.startsWith("Nessun") || item.startsWith("Tutti")) {
            JOptionPane.showMessageDialog(this, "Nessun contenuto disponibile da aggiungere.");
            return;
        }

        try {
            int idElemento = Integer.parseInt(item.split(" - ")[0]);

            ElementoMultimediale elemento = gestore.getElementoById(idElemento);
            if (elemento == null) {
                JOptionPane.showMessageDialog(this, "Errore: elemento non trovato.");
                return;
            }

            List<ElementoMultimediale> elementiEsistenti = gestore.getElementiPlaylist(playlist);
            
            // Controlla se già presente
            for (ElementoMultimediale e : elementiEsistenti) {
                if (e.getId() == idElemento) {
                    JOptionPane.showMessageDialog(this, 
                        "⚠️ Il contenuto è già presente nella playlist.",
                        "Contenuto già presente",
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }

            int nuovoOrdine = elementiEsistenti.size() + 1;

            boolean ok = gestore.aggiungiElementoAPlaylist(utente, playlist, elemento, nuovoOrdine);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Elemento aggiunto con successo!");
                caricaElementiPlaylist();
                caricaContenutiDisponibili();
            } else {
                JOptionPane.showMessageDialog(this, "Errore durante l'aggiunta dell'elemento.", "Errore", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Errore nel formato dell'elemento selezionato.");
        }
    }

    private void rimuoviElemento() {
        int row = tabellaElementi.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleziona un elemento da rimuovere.");
            return;
        }

        int idElemento = (int) modelElementi.getValueAt(row, 0);
        ElementoMultimediale elemento = gestore.getElementoById(idElemento);

        if (elemento == null) {
            JOptionPane.showMessageDialog(this, "Errore: elemento non trovato.");
            return;
        }

        int conferma = JOptionPane.showConfirmDialog(this,
            "Rimuovere l'elemento \"" + elemento.getTitolo() + "\" dalla playlist?",
            "Conferma rimozione",
            JOptionPane.YES_NO_OPTION);

        if (conferma == JOptionPane.YES_OPTION) {
            boolean ok = gestore.rimuoviElementoDaPlaylist(utente, playlist, elemento);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Elemento rimosso con successo!");
                caricaElementiPlaylist();
                caricaContenutiDisponibili();
            } else {
                JOptionPane.showMessageDialog(this, "Errore durante la rimozione.", "Errore", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void salvaOrdine() {
        int righe = modelElementi.getRowCount();
        if (righe == 0) {
            JOptionPane.showMessageDialog(this, "Nessun elemento nella playlist.");
            return;
        }

        for (int i = 0; i < righe; i++) {
            int idElemento = (int) modelElementi.getValueAt(i, 0);
            int nuovoOrdine = i + 1;
            gestore.aggiornaOrdineElemento(playlist, idElemento, nuovoOrdine);
        }

        if (playlist instanceof model.PlaylistCondivisa) {
            gestore.registraModifica(utente.getMatricola(), playlist.getId(), "modifica_ordine", "completata");
        }

        JOptionPane.showMessageDialog(this, "Ordine salvato con successo!");
        caricaElementiPlaylist();
    }
}